#ifndef OBJ_H
#define OBJ_H

#include "opengl.h"
#include <fstream>
#include <vector>
#include <string>
#include <sstream>


void loadOBJ(const char* filename);

#endif