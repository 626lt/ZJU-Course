The code is tested on Macos M2.

You can complie the code by running the following command:
```bash
make all
```
Meanwhile, you can run the code by running the following command if you don't want the orbit to be shown:
```bash
make all ORBIT=0
```
Or you can run the program directly by
```bash
make run
```